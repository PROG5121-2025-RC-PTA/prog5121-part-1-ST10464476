package model;

public class Student extends Person {
    private final int studentNumber;

    public Student(int studentNumber, String firstName, String lastName) {
        super(firstName, lastName);
        this.studentNumber = studentNumber;
    }

    public int getStudentNumber() { return studentNumber; }

    @Override
    public String toString() {
        return studentNumber + " - " + getDisplayName();
    }
}
