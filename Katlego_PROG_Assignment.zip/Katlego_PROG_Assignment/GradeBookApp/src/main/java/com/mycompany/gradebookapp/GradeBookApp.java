/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gradebookapp;

/**
 *
 * @author RC_Student_lab
 */
public class GradeBookApp {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
