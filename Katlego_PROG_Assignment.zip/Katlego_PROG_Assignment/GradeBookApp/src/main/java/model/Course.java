package model;

public class Course {
    private final String code;
    private String title;
    private final int maxMarks;

    public Course(String code, String title, int maxMarks) {
        this.code = code;
        this.title = title;
        this.maxMarks = maxMarks;
    }

    public String getCode() { return code; }
    public String getTitle() { return title; }
    public int getMaxMarks() { return maxMarks; }

    @Override
    public String toString() { return code + " - " + title; }
}
