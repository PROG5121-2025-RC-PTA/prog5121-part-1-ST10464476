package service;

import model.Course;
import model.Student;
import java.util.Arrays;

public class Gradebook {
    private final Student[] students;
    private final Course[] courses;
    private final double[][] marks;
    private int studentCount = 0;
    private int courseCount = 0;

    public Gradebook(int maxStudents, int maxCourses) {
        this.students = new Student[maxStudents];
        this.courses = new Course[maxCourses];
        this.marks = new double[maxStudents][maxCourses];
        for (int i = 0; i < maxStudents; i++) Arrays.fill(this.marks[i], -1);
    }

    public boolean addStudent(Student s) { students[studentCount++] = s; return true; }
    public boolean addCourse(Course c) { courses[courseCount++] = c; return true; }

    public boolean enrol(int studentNumber, String code) {
        int si = findStudent(studentNumber);
        int ci = findCourse(code);
        marks[si][ci] = 0; return true;
    }

    public boolean recordGrade(int studentNumber, String code, double mark) {
        int si = findStudent(studentNumber);
        int ci = findCourse(code);
        marks[si][ci] = mark; return true;
    }

    private int findStudent(int num) {
        for (int i = 0; i < studentCount; i++) 
            if (students[i].getStudentNumber() == num) return i;
        return -1;
    }

    private int findCourse(String code) {
        for (int i = 0; i < courseCount; i++) 
            if (courses[i].getCode().equalsIgnoreCase(code)) return i;
        return -1;
    }

    public double studentAverage(int si) {
        double total = 0; int count = 0;
        for (int ci = 0; ci < courseCount; ci++) 
            if (marks[si][ci] >= 0) { total += marks[si][ci]; count++; }
        return count == 0 ? 0 : total / count;
    }

    public double courseAverage(int ci) {
        double total = 0; int count = 0;
        for (int si = 0; si < studentCount; si++) 
            if (marks[si][ci] >= 0) { total += marks[si][ci]; count++; }
        return count == 0 ? 0 : total / count;
    }

    public Student[] getStudents() { return Arrays.copyOf(students, studentCount); }
    public Course[] getCourses() { return Arrays.copyOf(courses, courseCount); }

    public double[][] getMarks() {
        double[][] copy = new double[studentCount][courseCount];
        for (int i = 0; i < studentCount; i++) 
            copy[i] = Arrays.copyOf(marks[i], courseCount);
        return copy;
    }

    public int getStudentCount() { return studentCount; }
    public int getCourseCount() { return courseCount; }
}
