import java.util.ArrayList;
import java.util.Scanner;

public class Series {
    private ArrayList<SeriesModel> seriesList = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public void captureSeries() {
        System.out.print("Enter Series ID: ");
        String seriesId = scanner.nextLine();
        System.out.print("Enter Series Name: ");
        String seriesName = scanner.nextLine();
        String seriesAge;
        
        while (true) {
            System.out.print("Enter Series Age Restriction (2-18): ");
            seriesAge = scanner.nextLine();
            if (isValidAge(seriesAge)) break;
            System.out.println("Invalid age restriction. Please try again.");
        }

        System.out.print("Enter Number of Episodes: ");
        String seriesNumberOfEpisodes = scanner.nextLine();

        SeriesModel series = new SeriesModel(seriesId, seriesName, seriesAge, seriesNumberOfEpisodes);
        seriesList.add(series);
        System.out.println("Series details have been successfully saved.");
    }

    public void searchSeries() {
        System.out.print("Enter Series ID to search: ");
        String seriesId = scanner.nextLine();
        SeriesModel series = findSeries(seriesId);
        if (series != null) {
            displaySeries(series);
        } else {
            System.out.println("No series data could be found.");
        }
    }

    public void updateSeries() {
        System.out.print("Enter Series ID to update: ");
        String seriesId = scanner.nextLine();
        SeriesModel series = findSeries(seriesId);
        if (series != null) {
            System.out.print("Enter new Series Name: ");
            series.seriesName = scanner.nextLine();
            String seriesAge;

            while (true) {
                System.out.print("Enter new Series Age Restriction (2-18): ");
                seriesAge = scanner.nextLine();
                if (isValidAge(seriesAge)) break;
                System.out.println("Invalid age restriction. Please try again.");
            }
            series.seriesAge = seriesAge;
            System.out.print("Enter new Number of Episodes: ");
            series.seriesNumberOfEpisodes = scanner.nextLine();
            System.out.println("Series updated successfully.");
        } else {
            System.out.println("No series data could be found.");
        }
    }

    public void deleteSeries() {
        System.out.print("Enter Series ID to delete: ");
        String seriesId = scanner.nextLine();
        SeriesModel series = findSeries(seriesId);
        if (series != null) {
            System.out.print("Are you sure you want to delete this series? (yes/no): ");
            String confirmation = scanner.nextLine();
            if (confirmation.equalsIgnoreCase("yes")) {
                seriesList.remove(series);
                System.out.println("Series deleted successfully.");
            } else {
                System.out.println("Series deletion canceled.");
            }
        } else {
            System.out.println("No series data could be found.");
        }
    }

    public void seriesReport() {
        System.out.println("Series Report:");
        for (SeriesModel series : seriesList) {
            displaySeries(series);
            System.out.println("---------------------");
        }
    }

    public void exitSeriesApplication() {
        System.out.println("Exiting the application.");
        scanner.close();
        System.exit(0);
    }

    private boolean isValidAge(String age) {
        try {
            int ageNum = Integer.parseInt(age);
            return ageNum >= 2 && ageNum <= 18;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private SeriesModel findSeries(String seriesId) {
        for (SeriesModel series : seriesList) {
            if (series.seriesId.equals(seriesId)) {
                return series;
            }
        }
        return null;
    }

    private void displaySeries(SeriesModel series) {
        System.out.println("Series ID: " + series.seriesId);
        System.out.println("Series Name: " + series.seriesName);
        System.out.println("Series Age Restriction: " + series.seriesAge);
        System.out.println("Number of Episodes: " + series.seriesNumberOfEpisodes);
    }
}