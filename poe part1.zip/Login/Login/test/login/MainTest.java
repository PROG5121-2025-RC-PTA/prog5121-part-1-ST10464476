package login;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class MainTest {

    private Login login;

    @BeforeEach
    public void setUp() {
        login = new Login();
    }

    @Test
    public void testCheckUserName_Valid() {
        assertTrue(login.checkUserName("usr_1"));
    }

    @Test
    public void testCheckUserName_Invalid_NoUnderscore() {
        assertFalse(login.checkUserName("usr1"));
    }

    @Test
    public void testCheckUserName_Invalid_TooLong() {
        assertFalse(login.checkUserName("user_name_too_long"));
    }

    @Test
    public void testCheckPasswordComplexity_Valid() {
        assertTrue(login.checkPasswordComplexity("Strong1!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_NoUppercase() {
        assertFalse(login.checkPasswordComplexity("strong1!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_NoNumber() {
        assertFalse(login.checkPasswordComplexity("Strong!!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_NoSpecialCharacter() {
        assertFalse(login.checkPasswordComplexity("Strong1"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_ShortLength() {
        assertFalse(login.checkPasswordComplexity("S1!a"));
    }

    @Test
    public void testCheckCellPhoneNumber_Valid() {
        assertTrue(login.checkCellPhoneNumber("+27831234567"));
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid_NoInternationalCode() {
        assertFalse(login.checkCellPhoneNumber("0831234567"));
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid_WrongFormat() {
        assertFalse(login.checkCellPhoneNumber("+2783123abc"));
    }

    @Test
    public void testRegisterUser_Success() {
        String result = login.registerUser("usr_1", "Strong1!", "+27831234567", "Alice", "Smith");
        assertEquals("User registered successfully.", result);
    }

    @Test
    public void testRegisterUser_Failure() {
        login.registerUser("usr_1", "Strong1!", "+27831234567", "Alice", "Smith");
        String result = login.registerUser("usr_1", "Strong1!", "+27831234567", "Alice", "Smith");
        assertNotEquals("User registered successfully.", result);
    }

    @Test
    public void testReturnLoginStatus_Success() {
        login.registerUser("usr_1", "Strong1!", "+27831234567", "Alice", "Smith");
        String status = login.returnLoginStatus("usr_1", "Strong1!");
        assertEquals("Welcome Alice Smith, it is great to see you again.", status);
    }

    @Test
    public void testReturnLoginStatus_Failure() {
        login.registerUser("usr_1", "Strong1!", "+27831234567", "Alice", "Smith");
        String status = login.returnLoginStatus("usr_1", "WrongPass!");
        assertEquals("Username or password incorrect, please try again.", status);
    }
}
