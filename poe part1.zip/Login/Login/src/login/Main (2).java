/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package login;

import java.util.Scanner;
import login.Login;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login login = new Login();

        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();

        System.out.println("----- REGISTRATION -----");

        System.out.print("Enter username: ");
        String username = input.nextLine();
        System.out.println(login.checkUserName(username)
            ? "Username successfully captured."
            : "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");

        System.out.print("Enter password: ");
        String password = input.nextLine();
        System.out.println(login.checkPasswordComplexity(password)
            ? "Password successfully captured."
            : "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");

        System.out.print("Enter phone number (+27...): ");
        String phone = input.nextLine();
        System.out.println(login.checkCellPhoneNumber(phone)
            ? "Cell phone number successfully added."
            : "Cell phone number incorrectly formatted or does not contain international code.");

        String registrationResult = login.registerUser(username, password, phone, firstName, lastName);
        System.out.println(registrationResult);

        if (registrationResult.equals("User registered successfully.")) {
            System.out.println("----- LOGIN -----");
            System.out.print("Enter username: ");
            String loginUsername = input.nextLine();

            System.out.print("Enter password: ");
            String loginPassword = input.nextLine();

            System.out.println(login.returnLoginStatus(loginUsername, loginPassword));
        }

        input.close();
    }
}