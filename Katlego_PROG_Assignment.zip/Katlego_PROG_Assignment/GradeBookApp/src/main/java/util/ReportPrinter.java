package util;

import model.Course;
import model.Student;
import service.Gradebook;
import java.util.Locale;

public class ReportPrinter {
    public static void printFullReport(Gradebook gb) {
        System.out.println("==== GRADEBOOK REPORT ====");
        System.out.printf("Students: %d | Courses: %d%n", gb.getStudentCount(), gb.getCourseCount());

        Student[] students = gb.getStudents();
        Course[] courses = gb.getCourses();
        
        System.out.println("-- Per-Student Averages --");
        for (int i = 0; i < students.length; i++) {
            System.out.printf(Locale.US, "%s Average: %.2f%n", students[i], gb.studentAverage(i));
        }

        System.out.println("-- Per-Course Averages --");
        for (int ci = 0; ci < courses.length; ci++) {
            System.out.printf(Locale.US, "%s Avg: %.2f%n", courses[ci], gb.courseAverage(ci));
        }
    }
}

