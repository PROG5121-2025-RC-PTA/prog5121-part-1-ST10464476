import model.*;
import service.Gradebook;
import util.ReportPrinter;

public class Main {
    public static void main(String[] args) {
        Course[] courses = new Course[] {
            new Course("CS101", "Intro to CS", 100),
            new Course("MAT102", "Discrete Math", 100),
            new Course("PHY103", "Physics I", 100),
            new Course("ENG104", "Academic Writing", 100)
        };

        Student[] students = new Student[] {
            new Student(1001, "Katlego", "Moshaba"),
            new Student(1002, "Ava", "Ngwenya"),
            new Student(1003, "Rene", "Mokoena"),
            new Student(1004, "Neo", "Naidoo")
        };

        Gradebook gradebook = new Gradebook(30, 10);
        for (Course c : courses) gradebook.addCourse(c);
        for (Student s : students) gradebook.addStudent(s);

        for (Student s : students) {
            for (Course c : courses) {
                gradebook.enrol(s.getStudentNumber(), c.getCode());
            }
        }

        gradebook.recordGrade(1001, "CS101", 82);
        gradebook.recordGrade(1001, "MAT102", 74);
        gradebook.recordGrade(1001, "PHY103", 68);
        gradebook.recordGrade(1001, "ENG104", 88);

        gradebook.recordGrade(1002, "CS101", 91);
        gradebook.recordGrade(1002, "MAT102", 86);
        gradebook.recordGrade(1002, "PHY103", 79);
        gradebook.recordGrade(1002, "ENG104", 93);

        gradebook.recordGrade(1003, "CS101", 55);
        gradebook.recordGrade(1003, "MAT102", 64);
        gradebook.recordGrade(1003, "PHY103", 71);
        gradebook.recordGrade(1003, "ENG104", 58);

        gradebook.recordGrade(1004, "CS101", 73);
        gradebook.recordGrade(1004, "MAT102", 69);
        gradebook.recordGrade(1004, "PHY103", 77);
        gradebook.recordGrade(1004, "ENG104", 80);

        ReportPrinter.printFullReport(gradebook);
    }
}
